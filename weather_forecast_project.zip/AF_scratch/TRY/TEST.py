import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from tensorflow import keras
import joblib

# Load the pre-trained models
temperature_model = keras.models.load_model('D:/AF_scratch/trained_model/Temperature_model.h5')
humidity_model = keras.models.load_model('D:/AF_scratch/trained_model/Humidity_model.h5')
windspeed_model = keras.models.load_model('D:/AF_scratch/trained_model/Windspeed_model.h5')

# Load the classifier model
classifier_model = keras.models.load_model('D:/AF_scratch/trained_model/TH_GF_model.h5')

# Load the LabelEncoder for the classifier
classifier_label_encoder = joblib.load('D:/AF_scratch/trained_model/TH_GF_label_mapping.joblib')


# Define the forecast_weather function
def forecast_weather(model, data, target_column):
    # Create sequences for time series forecasting
    sequence_length = 24  # Using 24 hours as one sequence
    X, y = [], []

    for i in range(len(data) - sequence_length):
        seq = data.iloc[i:i + sequence_length]
        X.append(seq[['Hour', target_column]].values)
        y.append(data.iloc[i + sequence_length][target_column])

    X, y = np.array(X), np.array(y)

    # Split the dataset into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Get the last 24 points from the test set to use as input for prediction
    input_sequence = X_test[-1:]

    # Predict the next 6 points
    num_points_to_predict = st.slider(f'Number of Points to Predict for {target_column}', 1, 24, 6)
    forecasted_values = []

    for _ in range(num_points_to_predict):
        # Predict the next value
        next_value = model.predict(input_sequence)[0][0]

        # Update the input sequence with the predicted value and the current hour
        new_input_point = np.array([[data['Hour'].iloc[-num_points_to_predict + _], next_value]])
        input_sequence = np.concatenate([input_sequence[:, 1:, :], new_input_point.reshape(1, 1, 2)], axis=1)

        # Store the predicted value
        forecasted_values.append(next_value)

    # Generate time points for the forecast
    forecast_time_points = pd.date_range(data['Formatted Date'].max(), periods=num_points_to_predict + 1, freq='H')[1:]

    # Create a DataFrame for the predicted values
    forecasted_df = pd.DataFrame({'Time': forecast_time_points, f'Predicted {target_column}': forecasted_values})

    return forecasted_df
# Streamlit App
st.title('Weather Forecast App')
# File Uploader
uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])

# Display the uploaded data
if uploaded_file is not None:
    # Read the uploaded CSV file
    user_data = pd.read_csv(uploaded_file)

    # ... (Your existing code for processing the data)
    # Convert the 'Formatted Date' column to datetime format
    user_data['Formatted Date'] = pd.to_datetime(user_data['Formatted Date'], utc=True)

    # Allow users to input date range for slicing
    st.sidebar.subheader("Select Date Range")
    start_date = st.sidebar.date_input("Start Date", min(user_data['Formatted Date']).date())
    end_date = st.sidebar.date_input("End Date", max(user_data['Formatted Date']).date())

    # Convert start and end dates to datetime objects
    start_date = datetime.combine(start_date, datetime.min.time())
    end_date = datetime.combine(end_date, datetime.min.time()) + timedelta(days=1) - timedelta(microseconds=1)

    # Convert start and end dates to datetime64[ns, UTC]
    start_date = pd.to_datetime(start_date, utc=True)
    end_date = pd.to_datetime(end_date, utc=True)

    # Filter the dataset based on the selected date range
    sliced_data = user_data[
        (user_data['Formatted Date'] >= start_date) & (user_data['Formatted Date'] <= end_date)
    ]

    # Create a time-based feature (e.g., hour of the day)
    sliced_data['Hour'] = sliced_data['Formatted Date'].dt.hour
    # Display the sliced data
    st.subheader("Sliced Data:")
    st.write(sliced_data)


    # Add a "Predict" button
    if st.button("Predict"):
        # Perform predictions and display the results

        # Use the classifier model to predict weather condition
        last_temperature = sliced_data['Temperature (C)'].iloc[-1]
        last_humidity = sliced_data['Humidity'].iloc[-1]
        last_windspeed = sliced_data['Wind Speed (km/h)'].iloc[-1]

        weather_condition_input = np.array([[last_temperature, last_humidity, last_windspeed]])
        predicted_weather_condition_probabilities = classifier_model.predict(weather_condition_input)[0]
        predicted_weather_condition_classifier = np.argmax(predicted_weather_condition_probabilities)

        # Reshape to a 1D array before using inverse_transform
        predicted_weather_condition_classifier = np.array([predicted_weather_condition_classifier])

        # Convert the predicted class label back to the original label using the inverse_transform of the LabelEncoder
        predicted_weather_condition = classifier_label_encoder.inverse_transform(predicted_weather_condition_classifier)

        # Display the predicted weather condition from the classifier model at the top of the page
        st.subheader("Predicted Weather Condition (Classifier Model):")

        # Display the predicted weather condition in big block letters
        st.markdown(f"<h1 style='text-align: center;'>{predicted_weather_condition[0]}</h1>", unsafe_allow_html=True)

        # Display the predicted weather condition in regular text
        st.write(predicted_weather_condition[0])
        # ... (existing code)

        # Display the predicted weather condition from the classifier model at the top of the page
        st.subheader("Predicted Weather Condition (Classifier Model):")

        # Display the predicted weather condition in big block letters
        st.markdown(f"<h1 style='text-align: center;'>{predicted_weather_condition[0]}</h1>", unsafe_allow_html=True)

        # Display the predicted weather condition in regular text
        st.write(predicted_weather_condition[0])

        # ... (remaining code)


        # Temperature Forecasting
        st.subheader("Temperature Forecast:")
        temperature_data = sliced_data[['Formatted Date', 'Temperature (C)', 'Hour']]
        temperature_forecast = forecast_weather(temperature_model, temperature_data, 'Temperature (C)')

        # Humidity Forecasting
        st.subheader("Humidity Forecast:")
        humidity_data = sliced_data[['Formatted Date', 'Humidity', 'Hour']]
        humidity_forecast = forecast_weather(humidity_model, humidity_data, 'Humidity')

        # Wind Speed Forecasting
        st.subheader("Wind Speed Forecast:")
        windspeed_data = sliced_data[['Formatted Date', 'Wind Speed (km/h)', 'Hour']]
        windspeed_forecast = forecast_weather(windspeed_model, windspeed_data, 'Wind Speed (km/h)')

        # Display the forecasts
        st.subheader("Temperature Forecast:")
        st.write(temperature_forecast)

        st.subheader("Humidity Forecast:")
        st.write(humidity_forecast)

        st.subheader("Wind Speed Forecast:")
        st.write(windspeed_forecast)

        # Plot the results
        st.line_chart(temperature_forecast.set_index('Time'))
        st.line_chart(humidity_forecast.set_index('Time'))
        st.line_chart(windspeed_forecast.set_index('Time'))




